import 'package:path/path.dart';
import 'package:sqflite/sqflite.dart';
import '../models/part.dart';

/// طبقة قاعدة البيانات المحلية.
///
/// ملاحظة مهمة حول "البحث الدلالي":
/// النسخة الحالية تستخدم مطابقة كلمات مرجّحة (word-overlap scoring) وهي
/// تعطي نتائج جيدة فوراً وبدون أي اعتماديات خارجية أو نماذج يجب تنزيلها.
/// عندما تكون جاهزاً لبحث دلالي حقيقي (متجهات/embeddings):
///   1. أضف مكتبة sqlite-vec (إضافة SQLite رسمية تدعم البحث المتجهي).
///   2. ولّد متجه لكل قطعة عبر نموذج تضمين مصغّر يعمل على الجهاز
///      (مثال: all-MiniLM عبر ONNX Runtime Mobile).
///   3. خزّن المتجه في عمود BLOB واستبدل دالة `search` بمطابقة تشابه
///      جيبي (cosine similarity) بدل مطابقة الكلمات.
/// الكود أدناه مبني بحيث يسهل استبدال دالة `_score` فقط دون تغيير باقي التطبيق.
class DatabaseHelper {
  DatabaseHelper._internal();
  static final DatabaseHelper instance = DatabaseHelper._internal();
  Database? _db;

  Future<Database> get database async {
    _db ??= await _initDb();
    return _db!;
  }

  Future<Database> _initDb() async {
    final dbPath = await getDatabasesPath();
    final path = join(dbPath, 'carparts.db');
    return openDatabase(
      path,
      version: 1,
      onCreate: (db, version) async {
        await db.execute('''
          CREATE TABLE parts (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            part_number TEXT NOT NULL,
            brand TEXT NOT NULL,
            description TEXT NOT NULL,
            compatible_models TEXT NOT NULL,
            alt_numbers TEXT NOT NULL,
            price REAL,
            source TEXT NOT NULL DEFAULT 'local'
          )
        ''');
        await _seedSampleData(db);
      },
    );
  }

  Future<void> _seedSampleData(Database db) async {
    final samples = [
      CarPart(
        partNumber: '90915-YZZD4',
        brand: 'Toyota',
        description: 'فلتر زيت المحرك',
        compatibleModels: 'Camry 2007-2017, Corolla 2009-2019, RAV4 2013-2018',
        altNumbers: '90915-YZZD1, C-110',
      ),
      CarPart(
        partNumber: '04465-YZZE1',
        brand: 'Toyota',
        description: 'تيل فرامل أمامي',
        compatibleModels: 'Camry 2012-2017, Avalon 2013-2018',
        altNumbers: '04465-06120',
      ),
      CarPart(
        partNumber: '68010-002',
        brand: 'Denso',
        description: 'بخاخ وقود (حقن وقود)',
        compatibleModels: 'Elantra 2016-2020, Sonata 2015-2019',
        altNumbers: '35310-2E000',
      ),
      CarPart(
        partNumber: 'MN-1123',
        brand: 'Bosch',
        description: 'طقم بواجي (شمعات إشعال)',
        compatibleModels: 'Civic 2016-2021, Accord 2018-2022',
        altNumbers: '12401-5A2-A01',
      ),
    ];
    for (final p in samples) {
      await db.insert('parts', p.toMap()..remove('id'));
    }
  }

  Future<int> insertPart(CarPart part) async {
    final db = await database;
    return db.insert('parts', part.toMap()..remove('id'));
  }

  /// يستخدم عند حفظ نتائج مستخرجة من الإنترنت (مرحلة التعلّم التلقائي)
  Future<void> upsertFromWeb(CarPart part) async {
    final db = await database;
    final existing = await db.query(
      'parts',
      where: 'part_number = ? OR alt_numbers LIKE ?',
      whereArgs: [part.partNumber, '%${part.partNumber}%'],
      limit: 1,
    );
    if (existing.isEmpty) {
      await insertPart(part);
    }
  }

  /// بحث مرجّح بالكلمات — بديل خفيف وفوري للبحث الدلالي الكامل.
  Future<List<CarPart>> search(String query, {int limit = 20}) async {
    final db = await database;
    final all = await db.query('parts');
    final parts = all.map(CarPart.fromMap).toList();

    final queryWords = _normalize(query).split(' ').where((w) => w.isNotEmpty).toSet();
    if (queryWords.isEmpty) return parts.take(limit).toList();

    final scored = parts.map((p) {
      final haystack = _normalize(
        '${p.partNumber} ${p.brand} ${p.description} ${p.compatibleModels} ${p.altNumbers}',
      );
      final haystackWords = haystack.split(' ').toSet();
      final overlap = queryWords.where((w) => haystackWords.any((h) => h.contains(w) || w.contains(h))).length;
      final exactPartNumberBonus = haystack.contains(_normalize(query)) ? 5 : 0;
      return MapEntry(p, overlap + exactPartNumberBonus);
    }).where((e) => e.value > 0).toList();

    scored.sort((a, b) => b.value.compareTo(a.value));
    return scored.take(limit).map((e) => e.key).toList();
  }

  String _normalize(String s) => s
      .toLowerCase()
      .replaceAll(RegExp(r'[\u064B-\u0652]'), '') // إزالة التشكيل
      .replaceAll(RegExp(r'[^\w\s\u0600-\u06FF-]'), ' ')
      .trim();
}
