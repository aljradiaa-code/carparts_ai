import 'package:flutter/material.dart';
import 'package:flutter_gemma/core/api/flutter_gemma.dart';
import 'package:flutter_gemma/core/model_management/cancel_token.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'hf_repo_resolver.dart';
import 'model_catalog.dart';

/// حالة كل نموذج بالشاشة
enum _DownloadState { idle, resolving, downloading, installed, error }

class ModelDownloadScreen extends StatefulWidget {
  const ModelDownloadScreen({super.key});

  @override
  State<ModelDownloadScreen> createState() => _ModelDownloadScreenState();
}

class _ModelDownloadScreenState extends State<ModelDownloadScreen> {
  final Map<String, _DownloadState> _states = {};
  final Map<String, int> _progress = {};
  final Map<String, String> _errors = {};
  final Map<String, CancelToken> _cancelTokens = {};
  String? _activeModelId;

  @override
  void initState() {
    super.initState();
    _loadActiveModel();
  }

  Future<void> _loadActiveModel() async {
    final prefs = await SharedPreferences.getInstance();
    setState(() {
      _activeModelId = prefs.getString('active_llm_model_id');
      if (_activeModelId != null) {
        _states[_activeModelId!] = _DownloadState.installed;
      }
    });
  }

  Future<void> _download(LlmModelInfo model) async {
    setState(() {
      _states[model.id] = _DownloadState.resolving;
      _errors.remove(model.id);
      _progress[model.id] = 0;
    });

    try {
      // 1) اكتشاف رابط الملف الصحيح وقت التشغيل (لا نخزن رابط ثابت)
      final url = await HfRepoResolver.resolveTaskFileUrl(model.hfRepo);

      // 2) تحميل فعلي مع تتبع تقدّم + إمكانية إلغاء + إعادة محاولة تلقائية
      final cancelToken = CancelToken();
      _cancelTokens[model.id] = cancelToken;

      setState(() => _states[model.id] = _DownloadState.downloading);

      await FlutterGemma.installModel(modelType: model.modelType)
          .fromNetwork(url)
          .withCancelToken(cancelToken)
          .withProgress((progress) {
        if (!mounted) return;
        setState(() => _progress[model.id] = progress);
      }).install();

      // 3) نجاح — نحفظ هذا النموذج كنموذج نشط للتطبيق
      final prefs = await SharedPreferences.getInstance();
      await prefs.setString('active_llm_model_id', model.id);
      await prefs.setString('active_llm_model_type', model.modelType.name);

      if (!mounted) return;
      setState(() {
        _states[model.id] = _DownloadState.installed;
        _activeModelId = model.id;
      });
    } catch (e) {
      if (!mounted) return;
      final cancelled = CancelToken.isCancel(e);
      setState(() {
        _states[model.id] = cancelled ? _DownloadState.idle : _DownloadState.error;
        _errors[model.id] = cancelled ? 'تم إلغاء التحميل' : e.toString();
      });
    }
  }

  void _cancel(String modelId) {
    _cancelTokens[modelId]?.cancel('ألغى المستخدم التحميل');
  }

  @override
  Widget build(BuildContext context) {
    return Directionality(
      textDirection: TextDirection.rtl,
      child: Scaffold(
        appBar: AppBar(title: const Text('نموذج الذكاء الاصطناعي المحلي')),
        body: ListView(
          padding: const EdgeInsets.all(16),
          children: [
            const Text(
              'اختر نموذجاً واحداً — يُحمَّل مرة واحدة ويشتغل بعدها بدون '
              'إنترنت. يفضّل تحميله على شبكة واي فاي لأن الحجم قد يصل '
              'لعدة مئات من الميجابايت.',
              style: TextStyle(color: Colors.black54),
            ),
            const SizedBox(height: 16),
            ...kAvailableModels.map(_buildModelCard),
          ],
        ),
      ),
    );
  }

  Widget _buildModelCard(LlmModelInfo model) {
    final state = _states[model.id] ?? _DownloadState.idle;
    final isActive = _activeModelId == model.id;

    return Card(
      margin: const EdgeInsets.only(bottom: 12),
      child: Padding(
        padding: const EdgeInsets.all(12),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Row(
              children: [
                Expanded(
                  child: Text(model.displayName, style: const TextStyle(fontWeight: FontWeight.bold)),
                ),
                if (isActive)
                  const Chip(label: Text('مفعّل الآن'), backgroundColor: Color(0xFFDCEFDC)),
              ],
            ),
            const SizedBox(height: 4),
            Text('الحجم التقريبي: ${model.approxSize}', style: const TextStyle(fontSize: 12)),
            Text(model.notes, style: const TextStyle(fontSize: 12, color: Colors.black54)),
            if (model.requiresAuth)
              const Padding(
                padding: EdgeInsets.only(top: 4),
                child: Text(
                  '⚠️ يحتاج توكن HuggingFace (اطلب صلاحية على صفحة النموذج أولاً)',
                  style: TextStyle(fontSize: 12, color: Colors.orange),
                ),
              ),
            const SizedBox(height: 8),
            if (state == _DownloadState.downloading) ...[
              LinearProgressIndicator(value: (_progress[model.id] ?? 0) / 100),
              const SizedBox(height: 4),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Text('${_progress[model.id] ?? 0}%'),
                  TextButton(onPressed: () => _cancel(model.id), child: const Text('إلغاء')),
                ],
              ),
            ] else if (state == _DownloadState.resolving) ...[
              const LinearProgressIndicator(),
              const SizedBox(height: 4),
              const Text('جاري تحديد رابط التحميل...'),
            ] else if (state == _DownloadState.installed) ...[
              const Row(
                children: [
                  Icon(Icons.check_circle, color: Colors.green, size: 18),
                  SizedBox(width: 4),
                  Text('جاهز للاستخدام'),
                ],
              ),
            ] else ...[
              if (state == _DownloadState.error)
                Padding(
                  padding: const EdgeInsets.only(bottom: 6),
                  child: Text(
                    _errors[model.id] ?? 'حدث خطأ',
                    style: const TextStyle(color: Colors.red, fontSize: 12),
                  ),
                ),
              FilledButton.icon(
                onPressed: () => _download(model),
                icon: const Icon(Icons.download),
                label: Text(state == _DownloadState.error ? 'إعادة المحاولة' : 'تحميل وتفعيل'),
              ),
            ],
          ],
        ),
      ),
    );
  }
}
