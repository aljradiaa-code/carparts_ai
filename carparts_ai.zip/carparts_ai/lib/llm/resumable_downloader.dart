import 'dart:async';
import 'dart:io';
import 'package:http/http.dart' as http;
import 'package:path_provider/path_provider.dart';

typedef ProgressCallback = void Function(int downloadedBytes, int? totalBytes);

class DownloadCancelled implements Exception {}

/// منزّل ملفات قابل للاستئناف الحقيقي.
///
/// - يحفظ الملف الجزئي على القرص أثناء التحميل.
/// - عند انقطاع النت أو أي خطأ، يعيد المحاولة تلقائياً (حتى [maxRetries]
///   مرة) بفاصل زمني متزايد، ويطلب من الخادم إكمال الملف من نفس البايت
///   اللي وصلّه (Range header) بدل ما يبدأ من الصفر.
/// - لو الخادم ما يدعم الاستئناف الجزئي (يرجع الملف كامل من جديد)، يكتشف
///   هذا تلقائياً ويبدأ الملف من الصفر بدل ما يتلف الملف بدمج خاطئ.
/// - حتى لو التطبيق نفسه انقفل بالنص (مو بس ضعف نت)، الملف الجزئي يضل
///   محفوظ على القرص — فلما المستخدم يضغط "تحميل" مرة ثانية، يكمل من نفس
///   النقطة تلقائياً بدل ما يبدأ من جديد بالكامل.
class ResumableDownloader {
  http.Client? _client;
  bool _cancelled = false;

  void cancel() {
    _cancelled = true;
    _client?.close();
  }

  Future<String> download({
    required String url,
    required String fileName,
    ProgressCallback? onProgress,
    int maxRetries = 8,
    Map<String, String>? headers,
  }) async {
    _cancelled = false;
    final dir = await getApplicationSupportDirectory();
    final filePath = '${dir.path}/$fileName';
    final file = File(filePath);

    int attempt = 0;
    while (true) {
      attempt++;
      try {
        return await _attemptDownload(url, file, onProgress, headers);
      } catch (e) {
        if (_cancelled || e is DownloadCancelled) rethrow;
        if (attempt >= maxRetries) rethrow;
        await Future.delayed(Duration(seconds: _backoffSeconds(attempt)));
        // الحلقة تعيد المحاولة — الملف الجزئي محفوظ فتستأنف مو تبدأ من الصفر
      }
    }
  }

  int _backoffSeconds(int attempt) {
    const steps = [2, 4, 8, 16, 30];
    return attempt <= steps.length ? steps[attempt - 1] : 30;
  }

  Future<String> _attemptDownload(
    String url,
    File file,
    ProgressCallback? onProgress,
    Map<String, String>? extraHeaders,
  ) async {
    _client = http.Client();
    int existingBytes = await file.exists() ? await file.length() : 0;

    final request = http.Request('GET', Uri.parse(url));
    if (extraHeaders != null) request.headers.addAll(extraHeaders);
    if (existingBytes > 0) {
      request.headers['Range'] = 'bytes=$existingBytes-';
    }

    final response = await _client!.send(request);

    late final IOSink sink;
    int totalBytes;

    if (response.statusCode == 206) {
      // السيرفر أكّد دعم الاستئناف — نكمل إضافة على الملف الموجود
      sink = file.openWrite(mode: FileMode.append);
      totalBytes = _parseTotalFromContentRange(response.headers['content-range']) ??
          (existingBytes + (response.contentLength ?? 0));
    } else if (response.statusCode == 200) {
      // تجاهل السيرفر لطلب الاستئناف وأرسل الملف كامل — نبدأ من الصفر بأمان
      existingBytes = 0;
      sink = file.openWrite(mode: FileMode.write);
      totalBytes = response.contentLength ?? 0;
    } else {
      _client?.close();
      throw Exception('فشل التحميل: HTTP ${response.statusCode}');
    }

    int downloaded = existingBytes;
    try {
      await for (final chunk in response.stream) {
        if (_cancelled) throw DownloadCancelled();
        sink.add(chunk);
        downloaded += chunk.length;
        onProgress?.call(downloaded, totalBytes > 0 ? totalBytes : null);
      }
    } finally {
      await sink.flush();
      await sink.close();
      _client?.close();
    }

    if (totalBytes > 0 && downloaded < totalBytes) {
      throw Exception('توقف التحميل قبل الاكتمال ($downloaded من $totalBytes بايت)');
    }
    return file.path;
  }

  int? _parseTotalFromContentRange(String? header) {
    // الشكل المتوقع: "bytes 500-999/1234"
    if (header == null) return null;
    final parts = header.split('/');
    if (parts.length != 2) return null;
    return int.tryParse(parts[1]);
  }
}
