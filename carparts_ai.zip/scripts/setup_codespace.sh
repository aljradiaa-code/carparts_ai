#!/bin/bash
# سكربت تجهيز تلقائي — يثبّت Flutter + أدوات أندرويد داخل Codespaces
# شغّله مرة وحدة فقط بهذا الأمر (من مجلد carparts_ai):
#   bash scripts/setup_codespace.sh
set -e

echo "==> [1/5] تثبيت الأدوات الأساسية..."
sudo apt-get update -qq
sudo apt-get install -y -qq openjdk-17-jdk unzip curl >/dev/null

echo "==> [2/5] تحميل Flutter (قد يأخذ دقيقة أو دقيقتين)..."
if [ ! -d "$HOME/flutter" ]; then
  git clone -q https://github.com/flutter/flutter.git -b stable --depth 1 "$HOME/flutter"
fi
grep -qxF 'export PATH="$PATH:$HOME/flutter/bin"' ~/.bashrc || \
  echo 'export PATH="$PATH:$HOME/flutter/bin"' >> ~/.bashrc
export PATH="$PATH:$HOME/flutter/bin"

echo "==> [3/5] تحميل أدوات أندرويد (قد يأخذ عدة دقائق)..."
mkdir -p "$HOME/android-sdk/cmdline-tools"
if [ ! -d "$HOME/android-sdk/cmdline-tools/latest" ]; then
  cd "$HOME/android-sdk/cmdline-tools"
  curl -sS -o cmdline-tools.zip \
    https://dl.google.com/android/repository/commandlinetools-linux-11076708_latest.zip
  unzip -q cmdline-tools.zip
  mv cmdline-tools latest
  rm cmdline-tools.zip
fi

grep -qxF 'export ANDROID_HOME="$HOME/android-sdk"' ~/.bashrc || \
  echo 'export ANDROID_HOME="$HOME/android-sdk"' >> ~/.bashrc
grep -qxF 'export PATH="$PATH:$ANDROID_HOME/cmdline-tools/latest/bin:$ANDROID_HOME/platform-tools"' ~/.bashrc || \
  echo 'export PATH="$PATH:$ANDROID_HOME/cmdline-tools/latest/bin:$ANDROID_HOME/platform-tools"' >> ~/.bashrc
export ANDROID_HOME="$HOME/android-sdk"
export PATH="$PATH:$ANDROID_HOME/cmdline-tools/latest/bin:$ANDROID_HOME/platform-tools"

echo "==> [4/5] الموافقة على تراخيص أندرويد وتثبيت الحزم المطلوبة..."
yes | sdkmanager --licenses >/dev/null 2>&1 || true
sdkmanager --install "platform-tools" "platforms;android-34" "build-tools;34.0.0" >/dev/null

echo "==> [5/5] ربط Flutter بأدوات أندرويد..."
flutter config --android-sdk "$ANDROID_HOME" >/dev/null
flutter precache --android >/dev/null

echo ""
echo "✅ خلص التجهيز! افتح تيرمنال جديد (عشان يقرأ الإعدادات الجديدة) ثم شغّل:"
echo "   cd carparts_ai && flutter pub get && flutter build apk --release"
