import 'package:flutter/material.dart';
import 'package:flutter_gemma/core/api/flutter_gemma.dart';
import 'db/database_helper.dart';
import 'models/part.dart';
import 'llm/llm_query_service.dart';
import 'llm/model_download_screen.dart';
import 'import/import_screen.dart';

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  // نماذج Qwen2.5/SmolLM عامة ولا تحتاج توكن. لو أضفت لاحقاً نموذج مقيّد
  // (مثل Gemma) مرر التوكن هنا عبر --dart-define بدل كتابته مباشرة بالكود.
  FlutterGemma.initialize(
    huggingFaceToken: const String.fromEnvironment('HUGGINGFACE_TOKEN'),
    maxDownloadRetries: 10,
  );
  runApp(const CarPartsApp());
}

class CarPartsApp extends StatelessWidget {
  const CarPartsApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'قطع غيار ذكي',
      debugShowCheckedModeBanner: false,
      locale: const Locale('ar'),
      theme: ThemeData(
        colorSchemeSeed: Colors.indigo,
        useMaterial3: true,
        textTheme: const TextTheme().apply(fontSizeFactor: 1.0),
      ),
      home: const SearchScreen(),
    );
  }
}

class SearchScreen extends StatefulWidget {
  const SearchScreen({super.key});

  @override
  State<SearchScreen> createState() => _SearchScreenState();
}

class _SearchScreenState extends State<SearchScreen> {
  final _controller = TextEditingController();
  List<CarPart> _results = [];
  bool _loading = false;
  bool _searched = false;
  bool _modelReady = false;

  @override
  void initState() {
    super.initState();
    _checkModel();
  }

  Future<void> _checkModel() async {
    final ready = await LlmQueryService.isModelReady();
    if (mounted) setState(() => _modelReady = ready);
  }

  Future<void> _runSearch() async {
    final input = _controller.text.trim();
    if (input.isEmpty) return;
    setState(() {
      _loading = true;
      _searched = true;
    });

    // يستخدم النموذج المحلي لو موجود، وإلا يرجع تلقائياً للمحلل البسيط —
    // بدون أي فرق بالتعامل من هنا.
    final searchString = await LlmQueryService.parseToSearchString(input);
    final results = await DatabaseHelper.instance.search(searchString);

    setState(() {
      _results = results;
      _loading = false;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Directionality(
      textDirection: TextDirection.rtl,
      child: Scaffold(
        appBar: AppBar(
          title: const Text('ابحث عن قطعة غيار'),
          actions: [
            IconButton(
              tooltip: 'استيراد من ملف (PDF / Excel / CSV)',
              icon: const Icon(Icons.upload_file_outlined),
              onPressed: () async {
                await Navigator.push(
                  context,
                  MaterialPageRoute(builder: (_) => const ImportScreen()),
                );
                _runSearch();
              },
            ),
            IconButton(
              tooltip: 'نموذج الذكاء الاصطناعي المحلي',
              icon: Icon(_modelReady ? Icons.smart_toy : Icons.download_for_offline_outlined),
              onPressed: () async {
                await Navigator.push(
                  context,
                  MaterialPageRoute(builder: (_) => const ModelDownloadScreen()),
                );
                _checkModel();
              },
            ),
          ],
        ),
        body: Padding(
          padding: const EdgeInsets.all(16),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              TextField(
                controller: _controller,
                textInputAction: TextInputAction.search,
                onSubmitted: (_) => _runSearch(),
                decoration: InputDecoration(
                  hintText: 'مثال: فلتر زيت كامري 2015',
                  prefixIcon: const Icon(Icons.search),
                  border: OutlineInputBorder(borderRadius: BorderRadius.circular(12)),
                  suffixIcon: IconButton(
                    icon: const Icon(Icons.arrow_forward),
                    onPressed: _runSearch,
                  ),
                ),
              ),
              const SizedBox(height: 8),
              Text(
                _modelReady
                    ? '🤖 وضع الذكاء الاصطناعي المحلي مفعّل'
                    : 'بحث بالكلمات (اضغط أيقونة التحميل بالأعلى لتفعيل الذكاء الاصطناعي المحلي)',
                style: const TextStyle(fontSize: 12, color: Colors.black45),
              ),
              const SizedBox(height: 8),
              if (_loading) const LinearProgressIndicator(),
              if (!_loading && _searched && _results.isEmpty)
                const Padding(
                  padding: EdgeInsets.only(top: 32),
                  child: Center(child: Text('لا توجد نتائج مطابقة محلياً')),
                ),
              Expanded(
                child: ListView.separated(
                  itemCount: _results.length,
                  separatorBuilder: (_, __) => const SizedBox(height: 8),
                  itemBuilder: (context, i) {
                    final p = _results[i];
                    return Card(
                      child: ListTile(
                        title: Text('${p.brand} — ${p.description}'),
                        subtitle: Text(
                          'رقم القطعة: ${p.partNumber}\nمتوافق مع: ${p.compatibleModels}',
                        ),
                        isThreeLine: true,
                        trailing: p.price != null ? Text('${p.price} ') : null,
                      ),
                    );
                  },
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
