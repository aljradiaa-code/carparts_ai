import 'dart:convert';
import 'package:flutter_gemma/flutter_gemma.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../nlu/query_parser.dart';

/// يستخدم النموذج المحلي (لو تم تحميله من [ModelDownloadScreen]) لفهم
/// جملة البحث. إذا ما فيه نموذج منزّل، أو صار أي خطأ أثناء الاستدلال،
/// يرجع تلقائياً لمحلل القواعد البسيط [QueryParser] بدون ما يكسر التطبيق.
class LlmQueryService {
  static final QueryParser _fallbackParser = QueryParser();

  static Future<bool> isModelReady() async {
    final prefs = await SharedPreferences.getInstance();
    return prefs.getString('active_llm_model_id') != null;
  }

  static Future<String> parseToSearchString(String rawInput) async {
    final ready = await isModelReady();
    if (!ready) {
      return _fallbackParser.parse(rawInput).toSearchString();
    }

    InferenceModel? model;
    try {
      model = await FlutterGemma.getActiveModel(maxTokens: 512);
      final chat = await model.createChat(
        systemInstruction:
            'أنت أداة استخراج بيانات فقط. اقرأ رسالة المستخدم عن قطعة غيار سيارة '
            'وأخرج JSON واحد فقط بدون أي شرح أو نص إضافي بهذا الشكل بالضبط: '
            '{"brand": "", "model": "", "year": "", "part_type": ""}. '
            'اترك القيمة "" إذا لم تُذكر في الرسالة.',
      );
      await chat.addQueryChunk(Message.text(text: rawInput, isUser: true));
      final response = await chat.generateChatResponse();
      final responseText = '$response';

      final extracted = _extractJsonObject(responseText);
      if (extracted == null) {
        return _fallbackParser.parse(rawInput).toSearchString();
      }

      final map = jsonDecode(extracted) as Map<String, dynamic>;
      final fields = [map['brand'], map['model'], map['year'], map['part_type']]
          .whereType<String>()
          .map((s) => s.trim())
          .where((s) => s.isNotEmpty)
          .toList();

      if (fields.isEmpty) {
        return _fallbackParser.parse(rawInput).toSearchString();
      }
      return fields.join(' ');
    } catch (_) {
      // أي خطأ (نموذج غير متوافق، ذاكرة غير كافية، إخراج غير صالح...)
      // يرجّعنا فوراً للمحلل الاحتياطي بدل ما يعطّل البحث كامل.
      return _fallbackParser.parse(rawInput).toSearchString();
    } finally {
      await model?.close();
    }
  }

  static String? _extractJsonObject(String text) {
    final start = text.indexOf('{');
    final end = text.lastIndexOf('}');
    if (start == -1 || end == -1 || end < start) return null;
    return text.substring(start, end + 1);
  }
}
