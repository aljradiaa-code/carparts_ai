import 'dart:async';
import 'dart:io';
import 'package:http/http.dart' as http;
import 'package:path_provider/path_provider.dart';
import 'package:shared_preferences/shared_preferences.dart';

/// تقدّم التحميل: بايتات مستلمة من إجمالي البايتات (إن كان معروفاً).
class DownloadProgress {
  final int received;
  final int total; // -1 يعني غير معروف (السيرفر لم يرسل Content-Length)

  const DownloadProgress(this.received, this.total);

  int get percent =>
      total > 0 ? ((received / total) * 100).clamp(0, 100).round() : 0;

  String get humanReadable {
    String fmt(int bytes) {
      if (bytes >= 1024 * 1024 * 1024) {
        return '${(bytes / (1024 * 1024 * 1024)).toStringAsFixed(2)} GB';
      }
      return '${(bytes / (1024 * 1024)).toStringAsFixed(1)} MB';
    }

    if (total > 0) return '${fmt(received)} / ${fmt(total)}';
    return fmt(received);
  }
}

/// يُرمى عندما يلغي المستخدم التحميل يدوياً (وليس بسبب انقطاع الشبكة).
class DownloadCancelledException implements Exception {}

/// مدير تحميل يدعم:
///  - الاستكمال من حيث توقف (HTTP Range) حتى بعد إغلاق التطبيق كاملاً،
///    لأن نقطة الاستكمال هي حجم الملف الجزئي المخزّن فعلياً على القرص —
///    وليست حالة داخل الذاكرة تُفقد بإغلاق التطبيق.
///  - إعادة محاولة تلقائية بتأخير متصاعد (exponential backoff) عند أي
///    انقطاع اتصال، فلا يحتاج المستخدم يعيد الضغط على "تحميل" يدوياً.
///  - كشف تغيّر الملف المصدر (عبر ETag/Last-Modified) لتفادي استكمال
///    تحميل جزء قديم فوق ملف جديد وإنتاج ملف تالف.
class ResumableDownloader {
  final http.Client _client = http.Client();
  bool _cancelled = false;

  /// اطلب الإلغاء الصريح (زر "إلغاء" بالواجهة). لا يوقف إعادة المحاولة
  /// التلقائية الناتجة عن انقطاع الشبكة، بل فقط الإلغاء المتعمّد.
  void cancel() {
    _cancelled = true;
  }

  void dispose() => _client.close();

  static Future<Directory> _modelsDir() async {
    final base = await getApplicationSupportDirectory();
    final dir = Directory('${base.path}/models');
    if (!await dir.exists()) await dir.create(recursive: true);
    return dir;
  }

  /// مسار الملف الجزئي/النهائي لنموذج معيّن.
  static Future<File> partialFileFor(String modelId) async {
    final dir = await _modelsDir();
    return File('${dir.path}/$modelId.part');
  }

  static Future<File> finalFileFor(String modelId, String url) async {
    final dir = await _modelsDir();
    final ext = url.endsWith('.litertlm') ? 'litertlm' : 'task';
    return File('${dir.path}/$modelId.$ext');
  }

  /// يتحقق إن كان هناك تحميل متوقف مسبقاً لهذا النموذج، ويرجع حجمه
  /// بالبايت (0 لو لا يوجد). تُستخدم لعرض "لديك تحميل متوقف، استكمله".
  static Future<int> partialBytesFor(String modelId) async {
    final f = await partialFileFor(modelId);
    if (await f.exists()) return f.length();
    return 0;
  }

  /// يحمّل [url] لملف [modelId] المحلي. يرجّع المسار الكامل للملف
  /// الجاهز بعد التحقق من اكتماله بنجاح.
  Future<String> download({
    required String url,
    required String modelId,
    void Function(DownloadProgress progress)? onProgress,
    int maxRetries = 12,
  }) async {
    _cancelled = false;
    final partialFile = await partialFileFor(modelId);
    final prefs = await SharedPreferences.getInstance();
    final metaUrlKey = 'dl_source_url_$modelId';
    final metaTagKey = 'dl_validator_$modelId';

    // لو الرابط تغيّر منذ آخر محاولة (مثلاً تحديث النموذج على HuggingFace)
    // فالملف الجزئي القديم لم يعد صالحاً للاستكمال — نبدأ من جديد.
    final savedUrl = prefs.getString(metaUrlKey);
    if (savedUrl != null && savedUrl != url && await partialFile.exists()) {
      await partialFile.delete();
      await prefs.remove(metaTagKey);
    }
    await prefs.setString(metaUrlKey, url);

    int attempt = 0;
    while (true) {
      try {
        final path = await _attemptDownload(
          url: url,
          partialFile: partialFile,
          onProgress: onProgress,
          prefs: prefs,
          metaTagKey: metaTagKey,
        );
        final finalFile = await finalFileFor(modelId, url);
        if (await finalFile.exists()) await finalFile.delete();
        await partialFile.rename(finalFile.path);
        await prefs.remove(metaUrlKey);
        await prefs.remove(metaTagKey);
        return finalFile.path;
      } on DownloadCancelledException {
        rethrow; // إلغاء صريح من المستخدم — لا نعيد المحاولة
      } catch (e) {
        if (_cancelled) throw DownloadCancelledException();
        attempt++;
        if (attempt >= maxRetries) rethrow;
        // تأخير متصاعد: 2، 4، 8...، بحد أقصى 30 ثانية بين كل محاولة.
        final waitSeconds = (2 * attempt).clamp(2, 30);
        await Future.delayed(Duration(seconds: waitSeconds));
        // لا حاجة لأي إجراء إضافي: الملف الجزئي باق على القرص كما هو،
        // والمحاولة القادمة ستكمل تلقائياً من نفس حجمه الحالي.
      }
    }
  }

  Future<String> _attemptDownload({
    required String url,
    required File partialFile,
    required SharedPreferences prefs,
    required String metaTagKey,
    void Function(DownloadProgress progress)? onProgress,
  }) async {
    int downloaded =
        await partialFile.exists() ? await partialFile.length() : 0;

    final request = http.Request('GET', Uri.parse(url));
    if (downloaded > 0) {
      request.headers['Range'] = 'bytes=$downloaded-';
    }

    final http.StreamedResponse response;
    try {
      response = await _client.send(request);
    } on SocketException {
      rethrow; // شبكة مقطوعة — يُلتقط بالحلقة الخارجية لإعادة المحاولة
    }

    // 416: النطاق المطلوب غير صالح (الملف على السيرفر تغيّر/أصغر الآن)
    if (response.statusCode == 416) {
      await partialFile.delete();
      return _attemptDownload(
        url: url,
        partialFile: partialFile,
        prefs: prefs,
        metaTagKey: metaTagKey,
        onProgress: onProgress,
      );
    }

    if (response.statusCode != 200 && response.statusCode != 206) {
      throw Exception('فشل التحميل (HTTP ${response.statusCode})');
    }

    final isPartial = response.statusCode == 206;
    // تحقق من "مُوثّق التحقق" (ETag أو Last-Modified) — لو اختلف عن آخر
    // مرة يعني الملف المصدر تغيّر أثناء انقطاعنا، فنبدأ من جديد بدل
    // إنتاج ملف مدموج من نسختين مختلفتين وتالف.
    final validator =
        response.headers['etag'] ?? response.headers['last-modified'];
    final savedValidator = prefs.getString(metaTagKey);
    if (isPartial &&
        validator != null &&
        savedValidator != null &&
        validator != savedValidator) {
      await partialFile.delete();
      downloaded = 0;
      return _attemptDownload(
        url: url,
        partialFile: partialFile,
        prefs: prefs,
        metaTagKey: metaTagKey,
        onProgress: onProgress,
      );
    }
    if (validator != null) await prefs.setString(metaTagKey, validator);

    final startAt = isPartial ? downloaded : 0;
    final contentLength = response.contentLength ?? -1;
    final total = contentLength > 0
        ? (isPartial ? startAt + contentLength : contentLength)
        : -1;

    final sink = partialFile.openWrite(
      mode: startAt > 0 ? FileMode.append : FileMode.write,
    );
    int received = startAt;

    try {
      await for (final chunk in response.stream) {
        if (_cancelled) {
          throw DownloadCancelledException();
        }
        sink.add(chunk);
        received += chunk.length;
        onProgress?.call(DownloadProgress(received, total));
      }
    } finally {
      await sink.close();
    }

    if (total > 0 && received != total) {
      // اتصال انتهى بدون استلام كل البايتات المتوقعة — يُعامل كانقطاع
      // عادي، فتُعاد المحاولة تلقائياً من هذه النقطة بالحلقة الخارجية.
      throw Exception('اكتمل التحميل جزئياً فقط ($received من $total)');
    }

    return partialFile.path;
  }
}
