import 'dart:convert';
import 'package:http/http.dart' as http;

/// يكتشف رابط ملف .task (أو .litertlm كبديل) الصحيح داخل مستودع HuggingFace
/// وقت التشغيل، بدل تخزين رابط ثابت قد ينكسر مع أي تحديث لاسم الملف.
class HfRepoResolver {
  /// [token] مطلوب فقط للنماذج المقيّدة (requiresAuth = true في الكتالوج)
  static Future<String> resolveTaskFileUrl(String hfRepo, {String? token}) async {
    final apiUrl = Uri.parse('https://huggingface.co/api/models/$hfRepo/tree/main');
    final headers = <String, String>{
      if (token != null && token.isNotEmpty) 'Authorization': 'Bearer $token',
    };

    final response = await http.get(apiUrl, headers: headers);
    if (response.statusCode == 401 || response.statusCode == 403) {
      throw Exception(
        'هذا النموذج يحتاج صلاحية وصول (Request Access) على صفحة HuggingFace '
        'وتوكن صالح. تفقّد https://huggingface.co/$hfRepo',
      );
    }
    if (response.statusCode != 200) {
      throw Exception('تعذّر جلب قائمة ملفات $hfRepo (HTTP ${response.statusCode})');
    }

    final List<dynamic> files = jsonDecode(response.body) as List<dynamic>;
    final paths = files
        .map((f) => (f as Map<String, dynamic>)['path'] as String?)
        .whereType<String>()
        .toList();

    // نفضّل .task (الأكثر توافقاً مع الجوال)، ثم .litertlm كبديل.
    String? chosen = paths.firstWhere(
      (p) => p.endsWith('.task') && !p.contains('web'),
      orElse: () => '',
    );
    if (chosen == null || chosen.isEmpty) {
      chosen = paths.firstWhere((p) => p.endsWith('.litertlm'), orElse: () => '');
    }
    if (chosen == null || chosen.isEmpty) {
      throw Exception(
        'ما لقيت ملف .task أو .litertlm جاهز داخل $hfRepo. '
        'افتح https://huggingface.co/$hfRepo/tree/main وتأكد من نوع الملفات المتوفرة.',
      );
    }

    return 'https://huggingface.co/$hfRepo/resolve/main/$chosen';
  }
}
