import 'package:flutter/material.dart';
import 'package:flutter_gemma/core/api/flutter_gemma.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'hf_repo_resolver.dart';
import 'model_catalog.dart';
import 'resumable_downloader.dart';

/// حالة كل نموذج بالشاشة
enum _DownloadState { idle, resolving, downloading, installing, installed, error }

class ModelDownloadScreen extends StatefulWidget {
  const ModelDownloadScreen({super.key});

  @override
  State<ModelDownloadScreen> createState() => _ModelDownloadScreenState();
}

class _ModelDownloadScreenState extends State<ModelDownloadScreen> {
  final Map<String, _DownloadState> _states = {};
  final Map<String, DownloadProgress> _progress = {};
  final Map<String, String> _errors = {};
  final Map<String, ResumableDownloader> _downloaders = {};
  String? _activeModelId;

  @override
  void initState() {
    super.initState();
    _loadActiveModel();
    _checkResumableDownloads();
  }

  @override
  void dispose() {
    for (final d in _downloaders.values) {
      d.dispose();
    }
    super.dispose();
  }

  Future<void> _loadActiveModel() async {
    final prefs = await SharedPreferences.getInstance();
    setState(() {
      _activeModelId = prefs.getString('active_llm_model_id');
      if (_activeModelId != null) {
        _states[_activeModelId!] = _DownloadState.installed;
      }
    });
  }

  /// عند فتح الشاشة، نتحقق إن كان هناك تحميل متوقف من جلسة سابقة (حتى لو
  /// أُغلق التطبيق بالكامل) ونعرض ذلك للمستخدم بدل البدء من الصفر بصمت.
  Future<void> _checkResumableDownloads() async {
    for (final model in kAvailableModels) {
      final bytes = await ResumableDownloader.partialBytesFor(model.id);
      if (bytes > 0 && mounted) {
        setState(() {
          _states[model.id] = _DownloadState.idle;
          _progress[model.id] = DownloadProgress(bytes, -1);
        });
      }
    }
  }

  Future<void> _download(LlmModelInfo model) async {
    setState(() {
      _states[model.id] = _DownloadState.resolving;
      _errors.remove(model.id);
    });

    final downloader = ResumableDownloader();
    _downloaders[model.id] = downloader;

    try {
      // 1) اكتشاف رابط الملف الصحيح وقت التشغيل (لا نخزن رابط ثابت)
      final url = await HfRepoResolver.resolveTaskFileUrl(model.hfRepo);

      // 2) تحميل فعلي بنظامنا الخاص: يدعم الاستكمال الحقيقي عبر HTTP
      // Range من نفس النقطة التي توقف عندها آخر مرة، ويعيد المحاولة
      // تلقائياً عند أي انقطاع اتصال بدل تفريغ التقدّم بالكامل.
      setState(() => _states[model.id] = _DownloadState.downloading);

      final localPath = await downloader.download(
        url: url,
        modelId: model.id,
        onProgress: (p) {
          if (!mounted) return;
          setState(() => _progress[model.id] = p);
        },
      );

      // 3) الملف مكتمل ومتحقق منه محلياً — الآن فقط نسلّمه لـ flutter_gemma
      // لتثبيته كنموذج نشط (خطوة محلية بحتة لا تحتاج إنترنت).
      setState(() => _states[model.id] = _DownloadState.installing);

      await FlutterGemma.installModel(modelType: model.modelType)
          .fromFile(localPath)
          .install();

      final prefs = await SharedPreferences.getInstance();
      await prefs.setString('active_llm_model_id', model.id);
      await prefs.setString('active_llm_model_type', model.modelType.name);

      if (!mounted) return;
      setState(() {
        _states[model.id] = _DownloadState.installed;
        _activeModelId = model.id;
      });
    } catch (e) {
      if (!mounted) return;
      final cancelled = e is DownloadCancelledException;
      setState(() {
        _states[model.id] = cancelled ? _DownloadState.idle : _DownloadState.error;
        _errors[model.id] = cancelled
            ? 'تم إيقاف التحميل مؤقتاً — اضغط "استكمال" لمتابعته من نفس النقطة'
            : e.toString();
      });
    } finally {
      _downloaders.remove(model.id);
    }
  }

  void _cancel(String modelId) {
    _downloaders[modelId]?.cancel();
  }

  Future<void> _restartFromScratch(LlmModelInfo model) async {
    final f = await ResumableDownloader.partialFileFor(model.id);
    if (await f.exists()) await f.delete();
    setState(() {
      _progress.remove(model.id);
      _states[model.id] = _DownloadState.idle;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Directionality(
      textDirection: TextDirection.rtl,
      child: Scaffold(
        appBar: AppBar(title: const Text('نموذج الذكاء الاصطناعي المحلي')),
        body: ListView(
          padding: const EdgeInsets.all(16),
          children: [
            const Text(
              'اختر نموذجاً واحداً — يُحمَّل مرة واحدة ويشتغل بعدها بدون '
              'إنترنت. لو انقطع النت أثناء التحميل، التطبيق يكمل تلقائياً '
              'من حيث توقف بدل ما يبدأ من جديد.',
              style: TextStyle(color: Colors.black54),
            ),
            const SizedBox(height: 16),
            ...kAvailableModels.map(_buildModelCard),
          ],
        ),
      ),
    );
  }

  Widget _buildModelCard(LlmModelInfo model) {
    final state = _states[model.id] ?? _DownloadState.idle;
    final isActive = _activeModelId == model.id;
    final progress = _progress[model.id];
    final hasPartial = progress != null && progress.received > 0 && state != _DownloadState.installed;

    return Card(
      margin: const EdgeInsets.only(bottom: 12),
      child: Padding(
        padding: const EdgeInsets.all(12),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Row(
              children: [
                Expanded(
                  child: Text(model.displayName, style: const TextStyle(fontWeight: FontWeight.bold)),
                ),
                if (isActive)
                  const Chip(label: Text('مفعّل الآن'), backgroundColor: Color(0xFFDCEFDC)),
              ],
            ),
            const SizedBox(height: 4),
            Text('الحجم التقريبي: ${model.approxSize}', style: const TextStyle(fontSize: 12)),
            Text(model.notes, style: const TextStyle(fontSize: 12, color: Colors.black54)),
            if (model.requiresAuth)
              const Padding(
                padding: EdgeInsets.only(top: 4),
                child: Text(
                  '⚠️ يحتاج توكن HuggingFace (اطلب صلاحية على صفحة النموذج أولاً)',
                  style: TextStyle(fontSize: 12, color: Colors.orange),
                ),
              ),
            const SizedBox(height: 8),
            if (state == _DownloadState.downloading) ...[
              LinearProgressIndicator(value: progress != null && progress.total > 0 ? progress.percent / 100 : null),
              const SizedBox(height: 4),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Text(progress?.humanReadable ?? '...'),
                  TextButton(onPressed: () => _cancel(model.id), child: const Text('إيقاف مؤقت')),
                ],
              ),
            ] else if (state == _DownloadState.resolving) ...[
              const LinearProgressIndicator(),
              const SizedBox(height: 4),
              const Text('جاري تحديد رابط التحميل...'),
            ] else if (state == _DownloadState.installing) ...[
              const LinearProgressIndicator(),
              const SizedBox(height: 4),
              const Text('جاري التفعيل محلياً...'),
            ] else if (state == _DownloadState.installed) ...[
              const Row(
                children: [
                  Icon(Icons.check_circle, color: Colors.green, size: 18),
                  SizedBox(width: 4),
                  Text('جاهز للاستخدام'),
                ],
              ),
            ] else ...[
              if (state == _DownloadState.error)
                Padding(
                  padding: const EdgeInsets.only(bottom: 6),
                  child: Text(
                    _errors[model.id] ?? 'حدث خطأ',
                    style: const TextStyle(color: Colors.red, fontSize: 12),
                  ),
                ),
              if (hasPartial)
                Padding(
                  padding: const EdgeInsets.only(bottom: 6),
                  child: Text(
                    'لديك تحميل متوقف عند ${progress.humanReadable} — يمكنك استكماله.',
                    style: const TextStyle(fontSize: 12, color: Colors.blueGrey),
                  ),
                ),
              Row(
                children: [
                  Expanded(
                    child: FilledButton.icon(
                      onPressed: () => _download(model),
                      icon: Icon(hasPartial ? Icons.play_arrow : Icons.download),
                      label: Text(
                        hasPartial
                            ? 'استكمال التحميل'
                            : (state == _DownloadState.error ? 'إعادة المحاولة' : 'تحميل وتفعيل'),
                      ),
                    ),
                  ),
                  if (hasPartial) ...[
                    const SizedBox(width: 8),
                    IconButton(
                      tooltip: 'حذف والبدء من جديد',
                      icon: const Icon(Icons.delete_outline),
                      onPressed: () => _restartFromScratch(model),
                    ),
                  ],
                ],
              ),
            ],
          ],
        ),
      ),
    );
  }
}
