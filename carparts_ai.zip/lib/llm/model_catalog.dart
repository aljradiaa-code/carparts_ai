import 'package:flutter_gemma/flutter_gemma.dart';

/// كل نموذج هنا معرّف بـ repo على HuggingFace فقط (بدون رابط ملف مباشر).
/// السبب: أسماء ملفات .task تتغيّر بين تحديثات النماذج، فبدل ما نخزّن رابط
/// قد ينكسر، نكتشف الرابط الصحيح وقت التشغيل عبر [HfRepoResolver].
/// هذا يخلي شاشة التحميل تشتغل حتى لو حدّث فريق litert-community اسم الملف.
class LlmModelInfo {
  final String id; // معرّف داخلي فريد
  final String displayName;
  final String hfRepo; // مثال: litert-community/Qwen2.5-0.5B-Instruct
  final ModelType modelType;
  final bool requiresAuth; // يحتاج HuggingFace token (نماذج Gemma المقيّدة)
  final String approxSize;
  final String notes;

  const LlmModelInfo({
    required this.id,
    required this.displayName,
    required this.hfRepo,
    required this.modelType,
    required this.requiresAuth,
    required this.approxSize,
    required this.notes,
  });
}

/// قائمة منسّقة — كلها نماذج صغيرة تناسب الجوال وتدعم العربية.
/// الموصى به افتراضياً: Qwen2.5 0.5B (عام، بدون توكن، دعم عربي جيد).
const List<LlmModelInfo> kAvailableModels = [
  LlmModelInfo(
    id: 'qwen25_05b',
    displayName: 'Qwen2.5 0.5B (موصى به)',
    hfRepo: 'litert-community/Qwen2.5-0.5B-Instruct',
    modelType: ModelType.qwen,
    requiresAuth: false,
    approxSize: '~500MB-1GB',
    notes: 'متعدد اللغات ويدعم العربية، لا يحتاج توكن، مناسب لمعظم الأجهزة.',
  ),
  LlmModelInfo(
    id: 'smollm_135m',
    displayName: 'SmolLM 135M (الأخف)',
    hfRepo: 'litert-community/SmolLM-135M-Instruct',
    modelType: ModelType.general,
    requiresAuth: false,
    approxSize: '~135MB',
    notes: 'أخف نموذج وأسرع تحميل، لكن إنجليزي أساساً وفهمه للعربية محدود.',
  ),
  LlmModelInfo(
    id: 'gemma3_1b',
    displayName: 'Gemma 3 1B',
    hfRepo: 'litert-community/Gemma3-1B-IT',
    modelType: ModelType.gemmaIt,
    requiresAuth: true, // يحتاج طلب صلاحية على صفحة النموذج + توكن
    approxSize: '~500MB-1GB',
    notes: 'جودة أعلى، لكن يحتاج حساب HuggingFace وتوكن ("Request Access").',
  ),
];
