class CarPart {
  final int? id;
  final String partNumber;
  final String brand;
  final String description;
  final String compatibleModels; // e.g. "Camry 2015-2018, Corolla 2016-2019"
  final String altNumbers; // comma separated alternative part numbers
  final double? price;
  final String source; // "local" | "web:domain.com"

  CarPart({
    this.id,
    required this.partNumber,
    required this.brand,
    required this.description,
    required this.compatibleModels,
    required this.altNumbers,
    this.price,
    this.source = 'local',
  });

  Map<String, dynamic> toMap() => {
        'id': id,
        'part_number': partNumber,
        'brand': brand,
        'description': description,
        'compatible_models': compatibleModels,
        'alt_numbers': altNumbers,
        'price': price,
        'source': source,
      };

  factory CarPart.fromMap(Map<String, dynamic> m) => CarPart(
        id: m['id'] as int?,
        partNumber: m['part_number'] as String,
        brand: m['brand'] as String,
        description: m['description'] as String,
        compatibleModels: m['compatible_models'] as String,
        altNumbers: m['alt_numbers'] as String,
        price: (m['price'] as num?)?.toDouble(),
        source: m['source'] as String? ?? 'local',
      );
}
