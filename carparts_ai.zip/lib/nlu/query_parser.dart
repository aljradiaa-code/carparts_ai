/// محلل أوامر بحث بسيط (Rule-based NLU).
///
/// هذا يقوم بدور "الفهم" الذي كان مطلوباً من نموذج ذكاء اصطناعي محلي،
/// لكن بدون الحاجة لتنزيل/تشغيل نموذج لغوي ثقيل. يعمل فوراً بدون إنترنت.
///
/// عندما تريد الترقية لنموذج محلي حقيقي (Gemma 3 1B / Qwen2.5 0.5B عبر
/// MediaPipe LLM Inference API أو llama.cpp):
///   - اجعل هذا الملف يستدعي النموذج بدل القواعد، ويطلب منه إخراج JSON
///     بنفس شكل [ParsedQuery] (brand/model/year/partType). هذا يبقي بقية
///     التطبيق (قاعدة البيانات والواجهة) بدون أي تغيير.
class ParsedQuery {
  final String? brand;
  final String? model;
  final String? year;
  final String freeText;

  ParsedQuery({this.brand, this.model, this.year, required this.freeText});

  /// يبني نص بحث موحّد يُستخدم مع DatabaseHelper.search
  String toSearchString() {
    return [brand, model, year, freeText].where((e) => e != null && e.isNotEmpty).join(' ');
  }
}

class QueryParser {
  static const _knownBrands = [
    'toyota', 'تويوتا', 'hyundai', 'هيونداي', 'honda', 'هوندا',
    'nissan', 'نيسان', 'kia', 'كيا', 'bosch', 'بوش', 'denso', 'دينسو',
  ];

  static const _knownModels = [
    'camry', 'كامري', 'corolla', 'كورولا', 'elantra', 'النترا',
    'sonata', 'سوناتا', 'civic', 'سيفيك', 'accord', 'اكورد', 'rav4',
  ];

  ParsedQuery parse(String rawInput) {
    final lower = rawInput.toLowerCase();

    final brand = _knownBrands.firstWhere(
      (b) => lower.contains(b),
      orElse: () => '',
    );

    final model = _knownModels.firstWhere(
      (m) => lower.contains(m),
      orElse: () => '',
    );

    final yearMatch = RegExp(r'(19|20)\d{2}').firstMatch(rawInput);

    return ParsedQuery(
      brand: brand.isEmpty ? null : brand,
      model: model.isEmpty ? null : model,
      year: yearMatch?.group(0),
      freeText: rawInput,
    );
  }
}
