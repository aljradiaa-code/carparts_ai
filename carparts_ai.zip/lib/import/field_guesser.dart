import 'import_models.dart';

/// يحاول تخمين الحقل المناسب لكل عنوان عمود، بالعربي أو الإنجليزي،
/// بغضّ النظر عن اختلاف تسمية الأعمدة بين ملف وآخر. هذا تخمين أولي فقط
/// يعرضه المستخدم ويستطيع تعديله يدوياً قبل التأكيد — لا يوجد استيراد
/// تلقائي 100% بدون مراجعة بشرية لأن تنسيقات الملفات تختلف كثيراً.
class FieldGuesser {
  static const Map<PartField, List<String>> _synonyms = {
    PartField.partNumber: [
      'part number', 'partnumber', 'part_no', 'partno', 'p/n', 'pn',
      'sku', 'code', 'item code', 'رقم القطعة', 'رقم القطعه', 'الرقم',
      'كود', 'كود القطعة', 'رقم الصنف',
    ],
    PartField.brand: [
      'brand', 'manufacturer', 'make', 'maker', 'company',
      'الشركة', 'الشركة المصنعة', 'الماركة', 'الصانع', 'المصنع',
    ],
    PartField.description: [
      'description', 'desc', 'name', 'item', 'item name', 'product',
      'product name', 'title', 'الوصف', 'اسم القطعة', 'القطعة',
      'اسم الصنف', 'المنتج', 'البيان',
    ],
    PartField.compatibleModels: [
      'compatible', 'compatibility', 'models', 'fitment', 'fits',
      'vehicle', 'car model', 'متوافق', 'الموديلات', 'موديلات',
      'يتوافق مع', 'السيارات المتوافقة', 'الطراز',
    ],
    PartField.altNumbers: [
      'alt', 'alternative', 'equivalent', 'oem', 'cross reference',
      'أرقام بديلة', 'رقم بديل', 'البديل', 'أرقام مكافئة',
    ],
    PartField.price: [
      'price', 'cost', 'amount', 'value', 'السعر', 'التكلفة', 'القيمة',
      'سعر',
    ],
  };

  /// ينظّف النص: يزيل التشكيل والرموز، ويحوّل لحروف صغيرة، للمقارنة.
  static String _normalize(String s) => s
      .toLowerCase()
      .replaceAll(RegExp(r'[\u064B-\u0652]'), '')
      .replaceAll(RegExp(r'[^\w\s\u0600-\u06FF]'), ' ')
      .replaceAll(RegExp(r'\s+'), ' ')
      .trim();

  static PartField guess(String header) {
    final normalized = _normalize(header);
    if (normalized.isEmpty) return PartField.ignore;

    for (final entry in _synonyms.entries) {
      for (final syn in entry.value) {
        final normSyn = _normalize(syn);
        if (normalized == normSyn ||
            normalized.contains(normSyn) ||
            normSyn.contains(normalized)) {
          return entry.key;
        }
      }
    }
    return PartField.ignore;
  }

  /// يخمّن تعيين كل الأعمدة دفعة واحدة، ويتفادى تكرار نفس الحقل لعمودين
  /// (لو حدث تعارض، يفوز أول عمود ويُترك الباقي "تجاهل" ليقرر المستخدم).
  static List<PartField> guessAll(List<String> headers) {
    final used = <PartField>{};
    return headers.map((h) {
      final guessed = guess(h);
      if (guessed == PartField.ignore || used.contains(guessed)) {
        return PartField.ignore;
      }
      used.add(guessed);
      return guessed;
    }).toList();
  }
}
