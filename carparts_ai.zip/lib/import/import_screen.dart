import 'dart:io';
import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart';
import '../db/database_helper.dart';
import 'column_mapper_screen.dart';
import 'import_models.dart';
import 'pdf_table_extractor.dart';
import 'spreadsheet_parser.dart';

/// نقطة الدخول لاستيراد ملفات PDF / Excel / CSV محلياً إلى قاعدة
/// البيانات. تدعم ملفات بأي توزيع أعمدة — المستخدم يراجع ويربط
/// الأعمدة بنفسه بمساعدة تخمين تلقائي (انظر [ColumnMapperScreen]).
class ImportScreen extends StatefulWidget {
  const ImportScreen({super.key});

  @override
  State<ImportScreen> createState() => _ImportScreenState();
}

class _ImportScreenState extends State<ImportScreen> {
  bool _busy = false;
  String? _error;
  ImportResult? _lastResult;

  Future<void> _pickAndParse() async {
    setState(() {
      _error = null;
      _lastResult = null;
    });

    final picked = await FilePicker.platform.pickFiles(
      type: FileType.custom,
      allowedExtensions: ['pdf', 'xlsx', 'xls', 'csv'],
      withData: false,
    );
    if (picked == null || picked.files.single.path == null) return;

    final file = File(picked.files.single.path!);
    final ext = file.path.split('.').last.toLowerCase();

    setState(() => _busy = true);
    try {
      ParsedTable table;
      switch (ext) {
        case 'xlsx':
        case 'xls':
          table = await SpreadsheetParser.parseExcel(file);
          break;
        case 'csv':
          table = await SpreadsheetParser.parseCsv(file);
          break;
        case 'pdf':
          table = await PdfTableExtractor.parse(file);
          break;
        default:
          throw Exception('نوع ملف غير مدعوم: .$ext');
      }

      if (!mounted) return;
      if (table.isEmpty || table.headers.isEmpty) {
        setState(() {
          _error = 'ما قدرنا نستخرج أي بيانات جدولية من هذا الملف. '
              'لو كان PDF ممسوحاً ضوئياً (صورة) فهو يحتاج أداة OCR منفصلة أولاً.';
        });
        return;
      }

      final result = await Navigator.push<ImportResult>(
        context,
        MaterialPageRoute(builder: (_) => ColumnMapperScreen(table: table)),
      );
      if (result != null && mounted) {
        setState(() => _lastResult = result);
      }
    } catch (e) {
      if (mounted) setState(() => _error = 'فشلت قراءة الملف: $e');
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Directionality(
      textDirection: TextDirection.rtl,
      child: Scaffold(
        appBar: AppBar(title: const Text('استيراد قطع من ملف')),
        body: Padding(
          padding: const EdgeInsets.all(16),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              const Text(
                'استورد قطعاً من ملف Excel أو CSV أو PDF محفوظ على جهازك '
                'مباشرة إلى قاعدة البيانات — لا يحتاج إنترنت. الملفات '
                'المدعومة قد تختلف في ترتيب وأسماء الأعمدة؛ ستُعرض عليك '
                'معاينة لربط كل عمود بالحقل الصحيح قبل الاستيراد النهائي.',
                style: TextStyle(color: Colors.black54),
              ),
              const SizedBox(height: 20),
              FilledButton.icon(
                onPressed: _busy ? null : _pickAndParse,
                icon: const Icon(Icons.upload_file),
                label: const Text('اختيار ملف (PDF / Excel / CSV)'),
              ),
              const SizedBox(height: 16),
              if (_busy) const Center(child: CircularProgressIndicator()),
              if (_error != null)
                Card(
                  color: const Color(0xFFFDECEA),
                  child: Padding(
                    padding: const EdgeInsets.all(12),
                    child: Text(_error!, style: const TextStyle(color: Colors.red)),
                  ),
                ),
              if (_lastResult != null) _buildResultCard(_lastResult!),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildResultCard(ImportResult r) {
    return Card(
      color: const Color(0xFFEAF7EA),
      child: Padding(
        padding: const EdgeInsets.all(12),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text('تم الاستيراد', style: TextStyle(fontWeight: FontWeight.bold)),
            const SizedBox(height: 6),
            Text('إجمالي الصفوف بالملف: ${r.totalRows}'),
            Text('تم استيرادها بنجاح: ${r.imported}'),
            Text('مكررة (موجودة مسبقاً): ${r.skippedDuplicate}'),
            Text('غير صالحة (بيانات ناقصة): ${r.skippedInvalid}'),
            if (r.sampleErrors.isNotEmpty) ...[
              const SizedBox(height: 6),
              const Text('أمثلة على صفوف تم تجاوزها:', style: TextStyle(fontWeight: FontWeight.w600)),
              ...r.sampleErrors.take(5).map((e) => Text('• $e', style: const TextStyle(fontSize: 12))),
            ],
          ],
        ),
      ),
    );
  }
}
