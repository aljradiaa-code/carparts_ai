import 'package:flutter/material.dart';
import '../db/database_helper.dart';
import '../models/part.dart';
import 'field_guesser.dart';
import 'import_models.dart';

/// يعرض معاينة للجدول المستخرج من الملف، ويسمح للمستخدم بربط كل عمود
/// بحقل قاعدة البيانات المناسب — مع تخمين تلقائي أولي. هذه هي الآلية
/// التي تضمن نجاح الاستيراد "مهما اختلف توزيع الملف": بدل الاعتماد
/// الكامل على تخمين آلي قد يخطئ، يراجعه المستخدم بضغطات بسيطة.
class ColumnMapperScreen extends StatefulWidget {
  final ParsedTable table;
  const ColumnMapperScreen({super.key, required this.table});

  @override
  State<ColumnMapperScreen> createState() => _ColumnMapperScreenState();
}

class _ColumnMapperScreenState extends State<ColumnMapperScreen> {
  late List<PartField> _mapping;
  bool _importing = false;

  @override
  void initState() {
    super.initState();
    _mapping = FieldGuesser.guessAll(widget.table.headers);
  }

  bool get _isValidMapping =>
      _mapping.contains(PartField.partNumber) || _mapping.contains(PartField.description);

  Future<void> _confirmImport() async {
    setState(() => _importing = true);

    final headers = widget.table.headers;
    int imported = 0, dupes = 0, invalid = 0;
    final sampleErrors = <String>[];

    for (final row in widget.table.rows) {
      final values = <PartField, String>{};
      for (int i = 0; i < headers.length && i < row.length; i++) {
        final field = _mapping[i];
        if (field == PartField.ignore) continue;
        values[field] = row[i].trim();
      }

      final partNumber = values[PartField.partNumber] ?? '';
      final description = values[PartField.description] ?? '';

      // صف صالح إن كان فيه على الأقل رقم قطعة أو وصف — أي صف بدون أي
      // من الاثنين لا معنى له كقطعة غيار فنتجاوزه.
      if (partNumber.isEmpty && description.isEmpty) {
        invalid++;
        if (sampleErrors.length < 5) sampleErrors.add(row.join(' | '));
        continue;
      }

      final priceText = (values[PartField.price] ?? '').replaceAll(RegExp(r'[^\d.]'), '');
      final part = CarPart(
        partNumber: partNumber.isEmpty ? '—' : partNumber,
        brand: values[PartField.brand]?.isEmpty ?? true ? 'غير محدد' : values[PartField.brand]!,
        description: description.isEmpty ? partNumber : description,
        compatibleModels: values[PartField.compatibleModels] ?? '',
        altNumbers: values[PartField.altNumbers] ?? '',
        price: double.tryParse(priceText),
        source: 'import:${widget.table.sourceFileName}',
      );

      final wasNew = await DatabaseHelper.instance.upsertFromWebReturningStatus(part);
      if (wasNew) {
        imported++;
      } else {
        dupes++;
      }
    }

    if (!mounted) return;
    Navigator.pop(
      context,
      ImportResult(
        totalRows: widget.table.rows.length,
        imported: imported,
        skippedDuplicate: dupes,
        skippedInvalid: invalid,
        sampleErrors: sampleErrors,
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final headers = widget.table.headers;
    final previewRows = widget.table.rows.take(5).toList();

    return Directionality(
      textDirection: TextDirection.rtl,
      child: Scaffold(
        appBar: AppBar(title: Text('ربط الأعمدة — ${widget.table.sourceFileName}')),
        body: _importing
            ? const Center(child: CircularProgressIndicator())
            : Column(
                children: [
                  Padding(
                    padding: const EdgeInsets.all(12),
                    child: Text(
                      'وُجد ${widget.table.rows.length} صف. تحقق من ربط كل عمود '
                      'بالحقل الصحيح أدناه (خمّناها تلقائياً، عدّل ما تحتاجه فقط) '
                      'ثم اضغط "استيراد".',
                      style: const TextStyle(color: Colors.black54, fontSize: 13),
                    ),
                  ),
                  Expanded(
                    child: SingleChildScrollView(
                      scrollDirection: Axis.horizontal,
                      child: DataTable(
                        columns: headers
                            .map((h) => DataColumn(label: Text(h, style: const TextStyle(fontWeight: FontWeight.bold))))
                            .toList(),
                        rows: previewRows
                            .map(
                              (r) => DataRow(
                                cells: r.map((c) => DataCell(Text(c.length > 30 ? '${c.substring(0, 30)}…' : c))).toList(),
                              ),
                            )
                            .toList(),
                      ),
                    ),
                  ),
                  const Divider(height: 1),
                  Padding(
                    padding: const EdgeInsets.all(12),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.stretch,
                      children: [
                        const Text('ربط الأعمدة:', style: TextStyle(fontWeight: FontWeight.bold)),
                        const SizedBox(height: 8),
                        ...List.generate(headers.length, (i) => _buildMappingRow(i)),
                        const SizedBox(height: 12),
                        if (!_isValidMapping)
                          const Padding(
                            padding: EdgeInsets.only(bottom: 8),
                            child: Text(
                              '⚠️ اربط عموداً واحداً على الأقل بـ "رقم القطعة" أو "الوصف" للمتابعة.',
                              style: TextStyle(color: Colors.orange, fontSize: 12),
                            ),
                          ),
                        FilledButton.icon(
                          onPressed: _isValidMapping ? _confirmImport : null,
                          icon: const Icon(Icons.save_alt),
                          label: Text('استيراد ${widget.table.rows.length} صف'),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
      ),
    );
  }

  Widget _buildMappingRow(int i) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 4),
      child: Row(
        children: [
          Expanded(
            flex: 2,
            child: Text(widget.table.headers[i], overflow: TextOverflow.ellipsis),
          ),
          const Icon(Icons.arrow_back, size: 16, color: Colors.black38),
          Expanded(
            flex: 3,
            child: DropdownButton<PartField>(
              isExpanded: true,
              value: _mapping[i],
              items: PartField.values
                  .map((f) => DropdownMenuItem(value: f, child: Text(f.arabicLabel, style: const TextStyle(fontSize: 13))))
                  .toList(),
              onChanged: (v) {
                if (v == null) return;
                setState(() => _mapping[i] = v);
              },
            ),
          ),
        ],
      ),
    );
  }
}
