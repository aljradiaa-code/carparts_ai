import 'dart:io';
import 'package:pdf_text/pdf_text.dart';
import 'import_models.dart';

/// يستخرج بيانات من PDF ويحاول تحويلها لجدول.
///
/// يستخدم حزمة pdf_text_extract (رخصة MIT، بدون توكن أو تسجيل أو حد
/// أقصى تجريبي) — تعتمد على أدوات النظام نفسه لقراءة PDF (PDFKit على
/// آيفون، PdfBox-Android على أندرويد) فلا حاجة لأي إعداد إضافي.
///
/// تنبيه واقعي مهم: لا توجد طريقة تضمن قراءة أي PDF بأي تصميم بنسبة
/// 100% — PDF أصلاً تنسيق "عرض" وليس تنسيق "بيانات"، فالجدول بداخله قد
/// يكون نصاً منسّقاً بمسافات، أو حتى صورة ممسوحة ضوئياً بدون نص حقيقي
/// (عندها هذا الملف يحتاج OCR منفصل ولن يُستخرج شيء منه هنا).
///
/// الإستراتيجية المُتّبعة (عملية وواقعية بدل وعد بمثالية غير ممكنة):
///  1) استخراج النص الخام لكل صفحة مع الحفاظ على تقسيم الأسطر.
///  2) اعتبار كل سطر "صف" محتمل، وتقسيمه لأعمدة عبر أكبر فجوة مسافات
///     متكررة (Column-by-whitespace heuristic) — يعمل جيداً مع الجداول
///     المُصدَّرة من Excel/أنظمة نقاط البيع لملف PDF، وهي الحالة الأشيع.
///  3) لو السطر لا يحتوي فجوات كافية ليُقسَّم لأعمدة (نص حر غير جدولي)،
///     يُعامل كعمود واحد ("النص") ويُترك للمستخدم إكمال الحقول الأخرى
///     يدوياً أو تجاهله من شاشة المعاينة، بدل رفض الملف بالكامل.
class PdfTableExtractor {
  static Future<ParsedTable> parse(File file) async {
    final doc = await PDFDoc.fromFile(file);
    final buffer = StringBuffer();
    try {
      for (final page in doc.pages) {
        buffer.writeln(await page.text);
      }
    } finally {
      // يحذف النسخة المؤقتة الداخلية التي تستخدمها المكتبة، وليس ملف
      // المستخدم الأصلي (الذي يبقى في مكانه كما اختاره).
      doc.deleteFile();
    }

    final lines = buffer
        .toString()
        .split('\n')
        .map((l) => l.trimRight())
        .where((l) => l.trim().isNotEmpty)
        .toList();

    if (lines.isEmpty) {
      // على الأغلب PDF ممسوح ضوئياً (صور) بدون طبقة نص — لا يوجد شيء
      // نستخرجه بدون OCR منفصل.
      return ParsedTable(headers: const [], rows: const [], sourceFileName: file.uri.pathSegments.last);
    }

    final splitLines = lines.map(_splitByWhitespaceColumns).toList();

    // نحدد عدد الأعمدة "الغالب" بين الأسطر لاستنتاج بنية الجدول العامة.
    final columnCounts = <int, int>{};
    for (final l in splitLines) {
      columnCounts[l.length] = (columnCounts[l.length] ?? 0) + 1;
    }
    final dominantColumnCount = columnCounts.isEmpty
        ? 1
        : (columnCounts.entries.toList()..sort((a, b) => b.value.compareTo(a.value))).first.key;

    if (dominantColumnCount <= 1) {
      // لا يوجد نمط جدولي واضح — نرجّع كل سطر كعمود وصف واحد فقط،
      // ونترك المستخدم يقرر ماذا يفعل بها من شاشة المعاينة.
      return ParsedTable(
        headers: const ['النص'],
        rows: lines.map((l) => [l]).toList(),
        sourceFileName: file.uri.pathSegments.last,
      );
    }

    // أول سطر مطابق لعدد الأعمدة الغالب يُعتبر مرشّح عناوين.
    final headerIndex = splitLines.indexWhere((l) => l.length == dominantColumnCount);
    final headers = headerIndex >= 0
        ? splitLines[headerIndex]
        : List.generate(dominantColumnCount, (i) => 'عمود ${i + 1}');

    final dataRows = <List<String>>[];
    for (int i = 0; i < splitLines.length; i++) {
      if (i == headerIndex) continue;
      final row = splitLines[i];
      if (row.length == dominantColumnCount) {
        dataRows.add(row);
      } else if (row.length > dominantColumnCount) {
        dataRows.add(row.sublist(0, dominantColumnCount));
      } else {
        dataRows.add([...row, ...List.filled(dominantColumnCount - row.length, '')]);
      }
    }

    return ParsedTable(
      headers: headers,
      rows: dataRows,
      sourceFileName: file.uri.pathSegments.last,
    );
  }

  /// يقسّم سطراً لأعمدة بالاعتماد على فجوات مسافات ≥ 2 (النمط الشائع
  /// عند تصدير جداول لنص عادي)، بدل تقسيم بفراغ واحد الذي كان سيكسر
  /// أي وصف يحتوي أكثر من كلمة.
  static List<String> _splitByWhitespaceColumns(String line) {
    return line
        .split(RegExp(r'\s{2,}|\t+'))
        .map((c) => c.trim())
        .where((c) => c.isNotEmpty)
        .toList();
  }
}
