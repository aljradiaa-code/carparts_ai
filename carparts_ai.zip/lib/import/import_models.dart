/// جدول بيانات عام مستخرج من أي ملف (Excel/CSV/PDF) بغضّ النظر عن مصدره.
/// كل الملفات المدعومة تُحوَّل لهذا الشكل الموحّد قبل عرضها للمستخدم.
class ParsedTable {
  final List<String> headers;
  final List<List<String>> rows;
  final String sourceFileName;

  const ParsedTable({
    required this.headers,
    required this.rows,
    required this.sourceFileName,
  });

  bool get isEmpty => rows.isEmpty;
}

/// الحقول المتاحة في جدول parts بقاعدة البيانات — يُطابق المستخدم كل
/// عمود من الملف المستورد مع أحدها (أو "تجاهل" لو العمود غير مهم).
enum PartField {
  partNumber,
  brand,
  description,
  compatibleModels,
  altNumbers,
  price,
  ignore,
}

extension PartFieldLabel on PartField {
  String get arabicLabel {
    switch (this) {
      case PartField.partNumber:
        return 'رقم القطعة';
      case PartField.brand:
        return 'الشركة المصنّعة';
      case PartField.description:
        return 'الوصف / اسم القطعة';
      case PartField.compatibleModels:
        return 'الموديلات المتوافقة';
      case PartField.altNumbers:
        return 'أرقام بديلة';
      case PartField.price:
        return 'السعر';
      case PartField.ignore:
        return 'تجاهل هذا العمود';
    }
  }
}

/// نتيجة عملية الاستيراد — تُعرض للمستخدم بعد الانتهاء.
class ImportResult {
  final int totalRows;
  final int imported;
  final int skippedDuplicate;
  final int skippedInvalid;
  final List<String> sampleErrors;

  const ImportResult({
    required this.totalRows,
    required this.imported,
    required this.skippedDuplicate,
    required this.skippedInvalid,
    this.sampleErrors = const [],
  });
}
