import 'dart:convert';
import 'dart:io';
import 'package:csv/csv.dart';
import 'package:excel/excel.dart';
import 'import_models.dart';

/// يقرأ ملفات Excel (.xlsx) وCSV ويحوّلها لجدول موحّد [ParsedTable].
///
/// ملاحظات مهمة حول اختلاف التوزيع بين الملفات:
///  - يبحث تلقائياً عن أول صف يبدو "صف عناوين" حقيقي (بدل افتراض أن
///    الصف الأول دائماً هو العناوين) — بعض الملفات تبدأ بصفوف فارغة
///    أو بعنوان عام للجدول قبل صف العناوين الفعلي.
///  - يتجاهل الصفوف الفارغة تماماً بدل اعتبارها بيانات ناقصة.
///  - في Excel، لو كان هناك أكثر من ورقة (sheet)، يقرأ كل الأوراق التي
///    تحتوي بيانات فعلية، ويدمجها بجدول واحد (لأن بعض الموزّعين يوزّعون
///    القطع على أوراق متعددة حسب الفئة).
class SpreadsheetParser {
  static Future<ParsedTable> parseExcel(File file) async {
    final bytes = await file.readAsBytes();
    final excelFile = Excel.decodeBytes(bytes);

    List<String>? headers;
    final rows = <List<String>>[];

    for (final sheetName in excelFile.tables.keys) {
      final sheet = excelFile.tables[sheetName];
      if (sheet == null) continue;

      final rawRows = sheet.rows
          .map((r) => r.map((c) => c?.value?.toString().trim() ?? '').toList())
          .where((r) => r.any((cell) => cell.isNotEmpty))
          .toList();
      if (rawRows.isEmpty) continue;

      // أول صف غير فارغ في أول ورقة يحتوي بيانات = صف العناوين.
      if (headers == null) {
        headers = rawRows.first;
        rows.addAll(rawRows.skip(1));
      } else {
        // أوراق لاحقة: لو عناوينها مطابقة تقريباً نتجاهل صف العنوان
        // ونضيف بياناتها فقط، وإلا نضيفها كما هي (يقدر المستخدم يراجعها).
        final looksLikeHeader = _rowLooksLikeHeader(rawRows.first, headers);
        rows.addAll(looksLikeHeader ? rawRows.skip(1) : rawRows);
      }
    }

    return ParsedTable(
      headers: headers ?? [],
      rows: _normalizeWidth(headers?.length ?? 0, rows),
      sourceFileName: file.uri.pathSegments.last,
    );
  }

  static Future<ParsedTable> parseCsv(File file) async {
    // نحاول اكتشاف الترميز الأنسب؛ أغلب ملفات العرب تُصدَّر بترميز
    // UTF-8 أو Windows-1256. نبدأ بـ UTF-8 مع تجاوز الأخطاء بدل الانهيار.
    final content = await file.readAsString(encoding: const _LenientUtf8());
    // اكتشاف الفاصل تلقائياً: فاصلة، فاصلة منقوطة (شائعة بالملفات
    // العربية/الأوروبية)، أو تاب.
    final delimiter = _detectDelimiter(content);
    final rows = const CsvToListConverter(shouldParseNumbers: false)
        .convert(content, fieldDelimiter: delimiter)
        .map((r) => r.map((c) => c.toString().trim()).toList())
        .where((r) => r.any((c) => c.isNotEmpty))
        .toList();

    if (rows.isEmpty) {
      return ParsedTable(headers: const [], rows: const [], sourceFileName: file.uri.pathSegments.last);
    }

    final headers = rows.first;
    final dataRows = rows.skip(1).toList();

    return ParsedTable(
      headers: headers,
      rows: _normalizeWidth(headers.length, dataRows),
      sourceFileName: file.uri.pathSegments.last,
    );
  }

  static String _detectDelimiter(String sample) {
    final firstLine = sample.split('\n').first;
    final counts = {
      ',': ','.allMatches(firstLine).length,
      ';': ';'.allMatches(firstLine).length,
      '\t': '\t'.allMatches(firstLine).length,
    };
    return counts.entries.reduce((a, b) => a.value >= b.value ? a : b).key;
  }

  static bool _rowLooksLikeHeader(List<String> row, List<String> knownHeaders) {
    final overlap = row.where((c) => knownHeaders.contains(c)).length;
    return overlap >= (knownHeaders.length / 2).ceil();
  }

  /// يضمن أن كل صف بنفس عدد أعمدة صف العناوين (يقصّ الزائد، يكمل
  /// الناقص بخلايا فارغة) — يمنع أخطاء فهرسة عند ملفات غير منتظمة.
  static List<List<String>> _normalizeWidth(int width, List<List<String>> rows) {
    if (width == 0) return rows;
    return rows.map((r) {
      if (r.length == width) return r;
      if (r.length > width) return r.sublist(0, width);
      return [...r, ...List.filled(width - r.length, '')];
    }).toList();
  }
}

/// يقرأ الملف كـ UTF-8 لكن بدون رمي استثناء عند بايتات غير صالحة —
/// يستبدلها برمز بديل بدل تعطيل الاستيراد كاملاً بسبب حرف واحد تالف.
class _LenientUtf8 extends Encoding {
  const _LenientUtf8();
  @override
  String get name => 'utf-8-lenient';
  @override
  Converter<List<int>, String> get decoder => const Utf8Decoder(allowMalformed: true);
  @override
  Converter<String, List<int>> get encoder => const Utf8Encoder();
}
