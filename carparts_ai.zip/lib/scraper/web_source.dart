import '../models/part.dart';

/// واجهة موحّدة لأي "مصدر بيانات" خارجي — سواء كان API رسمي أو استخراج ويب.
///
/// توصية مهمة: ابدأ دائماً بالبحث عن API رسمي أو ملف بيانات (feed) من
/// موزّعي القطع قبل أي استخراج آلي من صفحات الويب. الاستخراج الآلي الذي
/// يحاكي متصفح بشري لتفادي الحظر قد يخالف شروط استخدام بعض المواقع، ومن
/// السهل أن ينكسر مع أي تحديث للصفحة. لهذا هذا الملف مجرد "عقد" (interface)
/// تقدر تبني عليه أي مصدر تتأكد أنه مسموح تقنياً وقانونياً.
abstract class WebPartsSource {
  String get sourceName;
  Future<List<CarPart>> searchOnline(String query);
}

/// مثال بديل — مصدر يعتمد على API رسمي بدل الاستخراج المباشر من HTML.
/// عبّئ [endpoint] و[apiKey] لو توفّر لديك اشتراك موزّع قطع يوفّر API.
class OfficialApiSource implements WebPartsSource {
  final String endpoint;
  final String? apiKey;

  OfficialApiSource({required this.endpoint, this.apiKey});

  @override
  String get sourceName => 'api:$endpoint';

  @override
  Future<List<CarPart>> searchOnline(String query) async {
    // TODO: نفّذ استدعاء HTTP فعلي هنا عبر package:http عندما يتوفر
    // اتصال إنترنت ومصدر API حقيقي. تركته فارغاً عمداً لأن أي رابط
    // وهمي هنا سيفشل، والأفضل تربطه بمصدر حقيقي تختاره.
    throw UnimplementedError(
      'اربط هذا بمصدر API حقيقي (endpoint + apiKey) قبل الاستخدام.',
    );
  }
}
